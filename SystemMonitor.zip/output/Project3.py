import psutil
import time
import os
import platform
import datetime
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from threading import Thread
import threading
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import pyperclip
import subprocess
from pathlib import Path
import sys
import logging

try:
    import GPUtil
    GPU_AVAILABLE = True
except ImportError:
    GPU_AVAILABLE = False

try:
    import wmi
    WMI_AVAILABLE = platform.system() == "Windows"
except ImportError:
    WMI_AVAILABLE = False

try:
    from pySMART import Device
    SMART_AVAILABLE = True
except ImportError:
    SMART_AVAILABLE = False

# Налаштування логування до файлу для діагностики
logging.basicConfig(filename='monitor.log', level=logging.DEBUG, format='%(asctime)s %(levelname)s: %(message)s')

class SystemMonitor:
    def __init__(self):
        # Redirect stdout to suppress console output
        self.original_stdout = sys.stdout
        self.devnull_file = open(os.devnull, 'w')
        sys.stdout = self.devnull_file

        self.root = tk.Tk()
        self.root.title("System Monitor")
        self.root.geometry("1000x700")
        self.root.minsize(800, 600)

        self.stop_event = threading.Event()  # Для управління потоками
        self.after_ids = []
        self.clear_tags_after_id = None
        self.cpu_usage_history = [[] for _ in range(psutil.cpu_count())]
        self.ram_usage_history = []
        self.gpu_usage_history = [] if GPU_AVAILABLE else None
        self.gpu_memory_history = [] if GPU_AVAILABLE else None
        self.gpu_temp_history = [] if GPU_AVAILABLE else None
        self.gpu_temp_min = float('inf') if GPU_AVAILABLE else None
        self.gpu_temp_max = float('-inf') if GPU_AVAILABLE else None
        self.disk_io_history_read = []
        self.disk_io_history_write = []
        self.net_download_history = []
        self.net_upload_history = []
        self.process_data = {}
        self.net_process_data = {}
        self.alert_log = []
        self.sort_column = "Memory_MB"
        self.net_sort_column = "Download_MB"
        self.sort_reverse = True
        self.net_sort_reverse = True
        self.max_history = 60
        self.cpu_threshold = 90
        self.ram_threshold = 90
        self.gpu_threshold = 85
        self.disk_space_threshold = 10
        self.net_traffic_threshold = 1100
        self.uptime_threshold = 7 * 24 * 3600
        self.reboot_history = []
        self.auto_export_interval = 300
        self.process_limit_warning_shown = False

        self.setup_gui()
        self.start_monitoring()

        self.root.bind("<Configure>", self.on_resize)

    def setup_gui(self):
        style = ttk.Style()
        style.configure("Treeview", rowheight=25)
        style.configure("Treeview.Heading", font=('Helvetica', 10, 'bold'))

        notebook_frame = ttk.Frame(self.root)
        notebook_frame.pack(fill="both", expand=True)

        self.notebook = ttk.Notebook(notebook_frame)
        self.notebook.pack(fill="both", expand=True)

        # CPU
        self.cpu_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.cpu_frame, text="CPU")

        self.cpu_label = ttk.Label(self.cpu_frame, text="Total CPU Usage: 0%", font=('Helvetica', 12))
        self.cpu_label.pack(pady=5)

        self.cpu_cores_frame = ttk.LabelFrame(self.cpu_frame, text="CPU Usage per Core (%)")
        self.cpu_cores_frame.pack(fill="x", pady=5)

        self.cpu_labels = []
        for i in range(psutil.cpu_count()):
            label = ttk.Label(self.cpu_cores_frame, text=f"Core {i}: 0.0%", width=15)
            label.grid(row=0, column=i % 8, padx=5, pady=5)
            self.cpu_labels.append(label)

        self.cpu_fig, self.cpu_ax = plt.subplots(figsize=(8, 4))
        self.cpu_canvas = FigureCanvasTkAgg(self.cpu_fig, master=self.cpu_frame)
        self.cpu_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=5)

        self.cpu_lines = []
        self.time_points = np.arange(self.max_history)
        colors = plt.cm.tab20(np.linspace(0, 1, psutil.cpu_count()))
        for i in range(psutil.cpu_count()):
            line, = self.cpu_ax.plot(self.time_points, [0] * self.max_history,
                                    label=f"Core {i}", color=colors[i])
            self.cpu_lines.append(line)

        self.cpu_ax.set_ylim(0, 100)
        self.cpu_ax.set_xlim(0, self.max_history - 1)
        self.cpu_ax.set_title("CPU Usage per Core")
        self.cpu_ax.set_xlabel("Time (s)")
        self.cpu_ax.set_ylabel("Usage (%)")
        self.cpu_ax.grid(True)
        self.cpu_ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        self.cpu_fig.tight_layout()

        # RAM
        self.ram_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.ram_frame, text="RAM")

        self.ram_label = ttk.Label(self.ram_frame, text="RAM Usage: 0%", font=('Helvetica', 12))
        self.ram_label.pack(pady=5)

        self.ram_fig, self.ram_ax = plt.subplots(figsize=(8, 4))
        self.ram_canvas = FigureCanvasTkAgg(self.ram_fig, master=self.ram_frame)
        self.ram_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=5)

        self.ram_line, = self.ram_ax.plot(self.time_points, [0] * self.max_history,
                                         label="RAM Usage", color='blue')
        self.ram_ax.set_ylim(0, 100)
        self.ram_ax.set_xlim(0, self.max_history - 1)
        self.ram_ax.set_title("RAM Usage Over Time")
        self.ram_ax.set_xlabel("Time (s)")
        self.ram_ax.set_ylabel("Usage (%)")
        self.ram_ax.grid(True)
        self.ram_ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        self.ram_fig.tight_layout()

        self.process_frame = ttk.LabelFrame(self.ram_frame, text="Running Processes")
        self.process_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.process_tree = ttk.Treeview(self.process_frame,
                                        columns=("PID", "Name", "Memory_MB", "Memory_Percent", "CPU_Percent"),
                                        show="headings",
                                        height=5)
        self.process_tree.pack(fill="both", expand=True, side=tk.LEFT)

        self.process_tree.heading("PID", text="PID", command=lambda: self.sort_treeview("PID"))
        self.process_tree.heading("Name", text="Process Name", command=lambda: self.sort_treeview("Name"))
        self.process_tree.heading("Memory_MB", text="Memory (MB)", command=lambda: self.sort_treeview("Memory_MB"))
        self.process_tree.heading("Memory_Percent", text="Memory (%)", command=lambda: self.sort_treeview("Memory_Percent"))
        self.process_tree.heading("CPU_Percent", text="CPU (%)", command=lambda: self.sort_treeview("CPU_Percent"))

        self.process_tree.column("PID", width=80, anchor="center")
        self.process_tree.column("Name", width=300)
        self.process_tree.column("Memory_MB", width=100, anchor="center")
        self.process_tree.column("Memory_Percent", width=100, anchor="center")
        self.process_tree.column("CPU_Percent", width=100, anchor="center")

        scrollbar = ttk.Scrollbar(self.process_frame, orient="vertical",
                                 command=self.process_tree.yview)
        scrollbar.pack(side=tk.RIGHT, fill="y")
        self.process_tree.configure(yscrollcommand=scrollbar.set)

        self.kill_button = ttk.Button(self.ram_frame, text="Kill Selected Process",
                                     command=self.kill_process)
        self.kill_button.pack(pady=5)

        # GPU
        self.gpu_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.gpu_frame, text="GPU")

        self.gpu_notebook = ttk.Notebook(self.gpu_frame)
        self.gpu_notebook.pack(fill="both", expand=True, padx=10, pady=5)

        if GPU_AVAILABLE:
            # GPU Usage Tab
            self.gpu_usage_frame = ttk.Frame(self.gpu_notebook)
            self.gpu_notebook.add(self.gpu_usage_frame, text="GPU Usage")

            self.gpu_usage_label = ttk.Label(self.gpu_usage_frame, text="Current: N/A", font=('Helvetica', 12))
            self.gpu_usage_label.pack(pady=5)

            self.gpu_usage_fig, self.gpu_usage_ax = plt.subplots(figsize=(8, 3))
            self.gpu_usage_canvas = FigureCanvasTkAgg(self.gpu_usage_fig, master=self.gpu_usage_frame)
            self.gpu_usage_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=5)

            self.gpu_usage_line, = self.gpu_usage_ax.plot(self.time_points, [0] * self.max_history,
                                                         label="GPU Usage", color='green')
            self.gpu_usage_ax.set_ylim(0, 100)
            self.gpu_usage_ax.set_xlim(0, self.max_history - 1)
            self.gpu_usage_ax.set_title("GPU Usage")
            self.gpu_usage_ax.set_xlabel("Time (s)")
            self.gpu_usage_ax.set_ylabel("Usage (%)")
            self.gpu_usage_ax.grid(True)
            self.gpu_usage_ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            self.gpu_usage_fig.tight_layout()

            # GPU Memory Tab
            self.gpu_memory_frame = ttk.Frame(self.gpu_notebook)
            self.gpu_notebook.add(self.gpu_memory_frame, text="GPU Memory")

            self.gpu_memory_label = ttk.Label(self.gpu_memory_frame, text="Used: N/A MB | Total: N/A MB | Percent: N/A%",
                                             font=('Helvetica', 12))
            self.gpu_memory_label.pack(pady=5)

            self.gpu_memory_fig, self.gpu_memory_ax = plt.subplots(figsize=(8, 3))
            self.gpu_memory_canvas = FigureCanvasTkAgg(self.gpu_memory_fig, master=self.gpu_memory_frame)
            self.gpu_memory_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=5)

            self.gpu_memory_line, = self.gpu_memory_ax.plot(self.time_points, [0] * self.max_history,
                                                           label="GPU Memory (%)", color='purple')
            self.gpu_memory_ax.set_ylim(0, 100)
            self.gpu_memory_ax.set_xlim(0, self.max_history - 1)
            self.gpu_memory_ax.set_title("GPU Memory Usage")
            self.gpu_memory_ax.set_xlabel("Time (s)")
            self.gpu_memory_ax.set_ylabel("Usage (%)")
            self.gpu_memory_ax.grid(True)
            self.gpu_memory_ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            self.gpu_memory_fig.tight_layout()

            # GPU Temperature Tab
            self.gpu_temp_frame = ttk.Frame(self.gpu_notebook)
            self.gpu_notebook.add(self.gpu_temp_frame, text="GPU Temperature")

            self.gpu_temp_label = ttk.Label(self.gpu_temp_frame, text="Current: N/A | Min: N/A | Max: N/A",
                                           font=('Helvetica', 12))
            self.gpu_temp_label.pack(pady=5)

            self.gpu_temp_fig, self.gpu_temp_ax = plt.subplots(figsize=(8, 3))
            self.gpu_temp_canvas = FigureCanvasTkAgg(self.gpu_temp_fig, master=self.gpu_temp_frame)
            self.gpu_temp_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=5)

            self.gpu_temp_line, = self.gpu_temp_ax.plot(self.time_points, [0] * self.max_history,
                                                       label="GPU Temp", color='red')
            self.gpu_temp_ax.set_ylim(0, 100)
            self.gpu_temp_ax.set_xlim(0, self.max_history - 1)
            self.gpu_temp_ax.set_title("GPU Temperature")
            self.gpu_temp_ax.set_xlabel("Time (s)")
            self.gpu_temp_ax.set_ylabel("Temp (°C)")
            self.gpu_temp_ax.grid(True)
            self.gpu_temp_ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            self.gpu_temp_fig.tight_layout()
        else:
            ttk.Label(self.gpu_frame, text="GPU monitoring unavailable (GPUtil not installed)",
                      font=('Helvetica', 12)).pack(pady=20)

        # Disk
        self.disk_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.disk_frame, text="Disk")

        self.disk_space_frame = ttk.LabelFrame(self.disk_frame, text="Disk Space")
        self.disk_space_frame.pack(fill="x", pady=5, padx=10)

        self.disk_label = ttk.Label(self.disk_space_frame, text="Disk Usage: N/A", font=('Helvetica', 12))
        self.disk_label.pack(pady=5)

        self.disk_smart_frame = ttk.LabelFrame(self.disk_frame, text="Disk Health (SMART)")
        self.disk_smart_frame.pack(fill="x", pady=5, padx=10)

        self.disk_smart_label = ttk.Label(self.disk_smart_frame, text="Temperature: N/A | Health: N/A", font=('Helvetica', 12))
        self.disk_smart_label.pack(pady=5)

        self.disk_io_fig, self.disk_io_ax = plt.subplots(figsize=(8, 3))
        self.disk_io_canvas = FigureCanvasTkAgg(self.disk_io_fig, master=self.disk_frame)
        self.disk_io_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=5)

        self.disk_io_read_line, = self.disk_io_ax.plot(self.time_points, [0] * self.max_history,
                                                      label="Read", color='blue')
        self.disk_io_write_line, = self.disk_io_ax.plot(self.time_points, [0] * self.max_history,
                                                       label="Write", color='orange')
        self.disk_io_ax.set_ylim(0, 10)
        self.disk_io_ax.set_xlim(0, self.max_history - 1)
        self.disk_io_ax.set_title("Disk I/O (MB/s)")
        self.disk_io_ax.set_xlabel("Time (s)")
        self.disk_io_ax.set_ylabel("Speed (MB/s)")
        self.disk_io_ax.grid(True)
        self.disk_io_ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        self.disk_io_fig.tight_layout()

        # Network
        self.net_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.net_frame, text="Network")

        self.net_label = ttk.Label(self.net_frame, text="Network: Download 0.0 Mbps | Upload 0.0 Mbps",
                                  font=('Helvetica', 12))
        self.net_label.pack(pady=5)

        self.net_fig, self.net_ax = plt.subplots(figsize=(8, 3))
        self.net_canvas = FigureCanvasTkAgg(self.net_fig, master=self.net_frame)
        self.net_canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=5)

        self.net_download_line, = self.net_ax.plot(self.time_points, [0] * self.max_history,
                                                  label="Download", color='blue')
        self.net_upload_line, = self.net_ax.plot(self.time_points, [0] * self.max_history,
                                                label="Upload", color='orange')
        self.net_ax.set_ylim(0, 10)
        self.net_ax.set_xlim(0, self.max_history - 1)
        self.net_ax.set_title("Network Activity (Mbps)")
        self.net_ax.set_xlabel("Time (s)")
        self.net_ax.set_ylabel("Speed (Mbps)")
        self.net_ax.grid(True)
        self.net_ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        self.net_fig.tight_layout()

        self.net_process_frame = ttk.LabelFrame(self.net_frame, text="Network-Using Processes")
        self.net_process_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.net_process_tree = ttk.Treeview(self.net_process_frame,
                                            columns=("PID", "Name", "Download_MB", "Upload_MB"),
                                            show="headings",
                                            height=5)
        self.net_process_tree.pack(fill="both", expand=True, side=tk.LEFT)

        self.net_process_tree.heading("PID", text="PID", command=lambda: self.sort_net_treeview("PID"))
        self.net_process_tree.heading("Name", text="Process Name", command=lambda: self.sort_net_treeview("Name"))
        self.net_process_tree.heading("Download_MB", text="Download (MB)", command=lambda: self.sort_net_treeview("Download_MB"))
        self.net_process_tree.heading("Upload_MB", text="Upload (MB)", command=lambda: self.sort_net_treeview("Upload_MB"))

        self.net_process_tree.column("PID", width=80, anchor="center")
        self.net_process_tree.column("Name", width=300)
        self.net_process_tree.column("Download_MB", width=100, anchor="center")
        self.net_process_tree.column("Upload_MB", width=100, anchor="center")

        net_scrollbar = ttk.Scrollbar(self.net_process_frame, orient="vertical",
                                     command=self.net_process_tree.yview)
        net_scrollbar.pack(side=tk.RIGHT, fill="y")
        self.net_process_tree.configure(yscrollcommand=net_scrollbar.set)

        # System Info
        self.sysinfo_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.sysinfo_frame, text="System Info")

        sysinfo_canvas = tk.Canvas(self.sysinfo_frame)
        sysinfo_scrollbar = ttk.Scrollbar(self.sysinfo_frame, orient="vertical", command=sysinfo_canvas.yview)
        sysinfo_scrollable_frame = ttk.Frame(sysinfo_canvas)

        sysinfo_scrollable_frame.bind(
            "<Configure>",
            lambda e: sysinfo_canvas.configure(scrollregion=sysinfo_canvas.bbox("all"))
        )

        sysinfo_canvas.create_window((0, 0), window=sysinfo_scrollable_frame, anchor="nw")
        sysinfo_canvas.configure(yscrollcommand=sysinfo_scrollbar.set)

        sysinfo_canvas.pack(side="left", fill="both", expand=True)
        sysinfo_scrollbar.pack(side="right", fill="y")

        self.uptime_frame = ttk.LabelFrame(sysinfo_scrollable_frame, text="System Uptime")
        self.uptime_frame.pack(fill="x", pady=5, padx=10)

        self.uptime_label = ttk.Label(self.uptime_frame, text="Uptime: 0d 0h 0m", font=('Helvetica', 10))
        self.uptime_label.pack(anchor="w", pady=2)

        self.last_boot_label = ttk.Label(self.uptime_frame, text="Last Boot: N/A", font=('Helvetica', 10))
        self.last_boot_label.pack(anchor="w", pady=2)

        self.reboot_history_frame = ttk.LabelFrame(sysinfo_scrollable_frame, text="Reboot History")
        self.reboot_history_frame.pack(fill="both", expand=True, pady=5, padx=10)

        self.reboot_tree = ttk.Treeview(self.reboot_history_frame, columns=("DateTime",), show="headings", height=5)
        self.reboot_tree.pack(fill="both", expand=True, side=tk.LEFT)

        self.reboot_tree.heading("DateTime", text="Reboot Date & Time")
        self.reboot_tree.column("DateTime", width=300, anchor="center")

        reboot_scrollbar = ttk.Scrollbar(self.reboot_history_frame, orient="vertical",
                                        command=self.reboot_tree.yview)
        reboot_scrollbar.pack(side=tk.RIGHT, fill="y")
        self.reboot_tree.configure(yscrollcommand=reboot_scrollbar.set)

        self.hardware_frame = ttk.LabelFrame(sysinfo_scrollable_frame, text="Hardware Information")
        self.hardware_frame.pack(fill="x", pady=5, padx=10)

        self.cpu_info_label = ttk.Label(self.hardware_frame, text="CPU: N/A", font=('Helvetica', 10))
        self.cpu_info_label.pack(anchor="w", pady=2)

        self.cpu_freq_label = ttk.Label(self.hardware_frame, text="CPU Frequency: N/A", font=('Helvetica', 10))
        self.cpu_freq_label.pack(anchor="w", pady=2)

        self.ram_info_label = ttk.Label(self.hardware_frame, text="RAM: N/A", font=('Helvetica', 10))
        self.ram_info_label.pack(anchor="w", pady=2)

        self.gpu_info_label = ttk.Label(self.hardware_frame, text="GPU: N/A", font=('Helvetica', 10))
        self.gpu_info_label.pack(anchor="w", pady=2)

        self.os_frame = ttk.LabelFrame(sysinfo_scrollable_frame, text="Operating System")
        self.os_frame.pack(fill="x", pady=5, padx=10)

        self.os_info_label = ttk.Label(self.os_frame, text="OS: N/A", font=('Helvetica', 10))
        self.os_info_label.pack(anchor="w", pady=2)

        self.drivers_frame = ttk.LabelFrame(sysinfo_scrollable_frame, text="Installed Drivers")
        self.drivers_frame.pack(fill="both", expand=True, pady=5, padx=10)

        self.drivers_tree = ttk.Treeview(self.drivers_frame,
                                        columns=("Name", "Version", "Status"),
                                        show="headings",
                                        height=10)
        self.drivers_tree.pack(fill="both", expand=True, side=tk.LEFT)

        self.drivers_tree.heading("Name", text="Driver Name")
        self.drivers_tree.heading("Version", text="Version")
        self.drivers_tree.heading("Status", text="Status")

        self.drivers_tree.column("Name", width=300)
        self.drivers_tree.column("Version", width=100, anchor="center")
        self.drivers_tree.column("Status", width=100, anchor="center")

        drivers_scrollbar = ttk.Scrollbar(self.drivers_frame, orient="vertical",
                                         command=self.drivers_tree.yview)
        drivers_scrollbar.pack(side=tk.RIGHT, fill="y")
        self.drivers_tree.configure(yscrollcommand=drivers_scrollbar.set)

        self.alert_frame = ttk.LabelFrame(sysinfo_scrollable_frame, text="Alert Log")
        self.alert_frame.pack(fill="both", expand=True, pady=5, padx=10)

        self.alert_tree = ttk.Treeview(self.alert_frame, columns=("Time", "Message"), show="headings", height=5)
        self.alert_tree.pack(fill="both", expand=True, side=tk.LEFT)

        self.alert_tree.heading("Time", text="Time")
        self.alert_tree.heading("Message", text="Message")
        self.alert_tree.column("Time", width=150, anchor="center")
        self.alert_tree.column("Message", width=400)

        alert_scrollbar = ttk.Scrollbar(self.alert_frame, orient="vertical",
                                       command=self.alert_tree.yview)
        alert_scrollbar.pack(side=tk.RIGHT, fill="y")
        self.alert_tree.configure(yscrollcommand=alert_scrollbar.set)

        self.copy_button = ttk.Button(sysinfo_scrollable_frame, text="Copy to Clipboard",
                                     command=self.copy_system_info)
        self.copy_button.pack(pady=5)

        self.export_button = ttk.Button(self.root, text="Export Data", command=self.manual_export_data)
        self.export_button.pack(pady=5)

        self.update_system_info()

    def on_resize(self, event):
        if self.stop_event.is_set():
            return
        window_width = self.root.winfo_width()
        window_height = self.root.winfo_height()
        new_figsize_width = max(6, window_width / 100)
        new_figsize_height = max(2, window_height / 200)

        self.cpu_fig.set_size_inches(new_figsize_width, new_figsize_height)
        self.ram_fig.set_size_inches(new_figsize_width, new_figsize_height)
        self.disk_io_fig.set_size_inches(new_figsize_width, new_figsize_height)
        self.net_fig.set_size_inches(new_figsize_width, new_figsize_height)
        if GPU_AVAILABLE:
            self.gpu_usage_fig.set_size_inches(new_figsize_width, new_figsize_height)
            self.gpu_memory_fig.set_size_inches(new_figsize_width, new_figsize_height)
            self.gpu_temp_fig.set_size_inches(new_figsize_width, new_figsize_height)

        self.cpu_canvas.draw()
        self.ram_canvas.draw()
        self.disk_io_canvas.draw()
        self.net_canvas.draw()
        if GPU_AVAILABLE:
            self.gpu_usage_canvas.draw()
            self.gpu_memory_canvas.draw()
            self.gpu_temp_canvas.draw()

    def sort_treeview(self, column):
        if self.sort_column == column:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_column = column
            self.sort_reverse = False
        self.update_process_list()

    def sort_net_treeview(self, column):
        if self.net_sort_column == column:
            self.net_sort_reverse = not self.net_sort_reverse
        else:
            self.net_sort_column = column
            self.net_sort_reverse = False
        self.update_net_process_list()

    def get_system_info(self):
        uptime_seconds = int(time.time() - psutil.boot_time())
        days, remainder = divmod(uptime_seconds, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, seconds = divmod(remainder, 60)
        uptime_str = f"{days}d {hours}h {minutes}m"
        return {
            "OS": platform.system() + " " + platform.release(),
            "CPU": platform.processor(),
            "RAM": f"{psutil.virtual_memory().total / (1024**3):.2f} GB",
            "Uptime": uptime_str,
            "Last Boot": datetime.datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
        }

    def update_system_info(self):
        cpu_model = platform.processor() or "N/A"
        self.cpu_info_label.config(text=f"CPU: {cpu_model}")

        try:
            cpu_freq = psutil.cpu_freq()
            freq_text = f"{cpu_freq.current:.2f} MHz (Max: {cpu_freq.max:.2f} MHz)" if cpu_freq else "N/A"
        except:
            freq_text = "N/A"
        self.cpu_freq_label.config(text=f"CPU Frequency: {freq_text}")

        ram_total = psutil.virtual_memory().total / (1024**3)
        self.ram_info_label.config(text=f"RAM: {ram_total:.2f} GB")

        gpu_info = "N/A"
        if GPU_AVAILABLE:
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu_info = f"{gpus[0].name} ({gpus[0].memoryTotal:.1f} MB)"
            except:
                pass
        self.gpu_info_label.config(text=f"GPU: {gpu_info}")

        os_info = f"{platform.system()} {platform.release()} ({platform.architecture()[0]})"
        self.os_info_label.config(text=f"OS: {os_info}")

        uptime_seconds = int(time.time() - psutil.boot_time())
        days, remainder = divmod(uptime_seconds, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, seconds = divmod(remainder, 60)
        self.uptime_label.config(text=f"Uptime: {days}d {hours}h {minutes}m")
        self.last_boot_label.config(text=f"Last Boot: {datetime.datetime.fromtimestamp(psutil.boot_time()).strftime('%Y-%m-%d %H:%M:%S')}")

        if not self.reboot_history:
            self.reboot_history.append(datetime.datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S"))
        self.reboot_tree.delete(*self.reboot_tree.get_children())
        for reboot_time in self.reboot_history:
            self.reboot_tree.insert("", "end", values=(reboot_time,))

        self.drivers_tree.delete(*self.drivers_tree.get_children())
        if platform.system() == "Windows" and WMI_AVAILABLE:
            try:
                c = wmi.WMI()
                drivers = c.Win32_PnPSignedDriver()
                for driver in drivers:
                    name = driver.DeviceName or "Unknown"
                    version = driver.DriverVersion or "N/A"
                    status = driver.Status or "N/A"
                    self.drivers_tree.insert("", "end", values=(name, version, status))
            except Exception as e:
                self.drivers_tree.insert("", "end", values=("Error retrieving drivers", str(e), "N/A"))
        elif platform.system() == "Linux":
            try:
                result = subprocess.run(['lsmod'], capture_output=True, text=True)
                modules = result.stdout.splitlines()[1:]
                for module in modules:
                    name = module.split()[0]
                    self.drivers_tree.insert("", "end", values=(name, "N/A", "Loaded"))
            except Exception as e:
                self.drivers_tree.insert("", "end", values=("Error retrieving modules", str(e), "N/A"))
        else:
            self.drivers_tree.insert("", "end", values=("Driver info not fully supported", "N/A", "N/A"))

        self.alert_tree.delete(*self.alert_tree.get_children())
        for alert in self.alert_log[-10:]:
            time_str, message = alert.split(": ", 1)
            self.alert_tree.insert("", "end", values=(time_str, message))

    def copy_system_info(self):
        info_text = ""
        info_text += f"CPU: {self.cpu_info_label['text'].split(': ')[1]}\n"
        info_text += f"CPU Frequency: {self.cpu_freq_label['text'].split(': ')[1]}\n"
        info_text += f"RAM: {self.ram_info_label['text'].split(': ')[1]}\n"
        info_text += f"GPU: {self.gpu_info_label['text'].split(': ')[1]}\n"
        info_text += f"OS: {self.os_info_label['text'].split(': ')[1]}\n"
        info_text += f"Uptime: {self.uptime_label['text'].split(': ')[1]}\n"
        info_text += f"Last Boot: {self.last_boot_label['text'].split(': ')[1]}\n"
        info_text += "\nInstalled Drivers:\n"
        for item in self.drivers_tree.get_children():
            values = self.drivers_tree.item(item, "values")
            info_text += f"Name: {values[0]}, Version: {values[1]}, Status: {values[2]}\n"
        info_text += "\nAlert Log:\n"
        for item in self.alert_tree.get_children():
            values = self.alert_tree.item(item, "values")
            info_text += f"{values[0]}: {values[1]}\n"

        pyperclip.copy(info_text)
        messagebox.showinfo("Success", "System information copied to clipboard!")

    def monitor_cpu(self):
        while not self.stop_event.is_set():
            try:
                cpu_percent = psutil.cpu_percent(percpu=True)
                total_cpu = psutil.cpu_percent()
                self.root.after(0, lambda: self.update_cpu_gui(total_cpu, cpu_percent))
            except Exception as e:
                logging.error(f"Error in monitor_cpu: {e}")
            time.sleep(3)

    def update_cpu_gui(self, total_cpu, cpu_percent):
        if self.stop_event.is_set():
            return
        self.cpu_label.config(text=f"Total CPU Usage: {total_cpu:.1f}%")
        recommendation = "Recommendation: Close high-CPU processes."
        if total_cpu > self.cpu_threshold:
            self.cpu_label.config(foreground="red")
            alert_msg = f"CPU usage exceeded {self.cpu_threshold}%: {total_cpu:.1f}%"
            self.alert_log.append(f"{datetime.datetime.now()}: {alert_msg}")
            messagebox.showwarning("CPU Warning", f"{alert_msg}\n{recommendation}")
        else:
            self.cpu_label.config(foreground="black")

        for i, percent in enumerate(cpu_percent):
            color = "red" if percent > 90 else "orange" if percent > 70 else "black"
            self.cpu_labels[i].config(text=f"Core {i}: {percent:.1f}%", foreground=color)

        for i, percent in enumerate(cpu_percent):
            self.cpu_usage_history[i].append(percent)
            if len(self.cpu_usage_history[i]) > self.max_history:
                self.cpu_usage_history[i].pop(0)

        for i, line in enumerate(self.cpu_lines):
            data = self.cpu_usage_history[i] + [0] * (self.max_history - len(self.cpu_usage_history[i]))
            line.set_ydata(data)

        self.cpu_ax.relim()
        self.cpu_ax.autoscale_view()
        self.cpu_canvas.draw()

    def monitor_ram(self):
        while not self.stop_event.is_set():
            try:
                ram = psutil.virtual_memory()
                self.root.after(0, lambda: self.update_ram_gui(ram))
            except Exception as e:
                logging.error(f"Error in monitor_ram: {e}")
            time.sleep(3)

    def update_ram_gui(self, ram):
        if self.stop_event.is_set():
            return
        self.ram_label.config(text=f"RAM Usage: {ram.percent:.1f}% "
                                  f"({ram.used/(1024**3):.2f}/{ram.total/(1024**3):.2f} GB, "
                                  f"Free: {ram.free/(1024**3):.2f} GB)")
        recommendation = "Recommendation: Close high-memory processes."
        if ram.percent > self.ram_threshold:
            self.ram_label.config(foreground="red")
            alert_msg = f"RAM usage exceeded {self.ram_threshold}%: {ram.percent:.1f}%"
            self.alert_log.append(f"{datetime.datetime.now()}: {alert_msg}")
            messagebox.showwarning("RAM Warning", f"{alert_msg}\n{recommendation}")
        else:
            self.ram_label.config(foreground="black")

        self.ram_usage_history.append(ram.percent)
        if len(self.ram_usage_history) > self.max_history:
            self.ram_usage_history.pop(0)

        ram_data = self.ram_usage_history + [0] * (self.max_history - len(self.ram_usage_history))
        self.ram_line.set_ydata(ram_data)
        self.ram_ax.relim()
        self.ram_ax.autoscale_view()
        self.ram_canvas.draw()

        self.update_process_list()

    def monitor_gpu(self):
        if not GPU_AVAILABLE:
            return
        while not self.stop_event.is_set():
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]
                    gpu_usage = gpu.load * 100
                    gpu_memory_used = gpu.memoryUsed
                    gpu_memory_total = gpu.memoryTotal
                    gpu_memory_percent = (gpu_memory_used / gpu_memory_total) * 100
                    gpu_temp = gpu.temperature
                    self.gpu_temp_min = min(self.gpu_temp_min, gpu_temp)
                    self.gpu_temp_max = max(self.gpu_temp_max, gpu_temp)
                    self.root.after(0, lambda: self.update_gpu_gui(gpu_usage, gpu_memory_used, gpu_memory_total,
                                                                  gpu_memory_percent, gpu_temp))
                else:
                    self.root.after(0, lambda: self.update_gpu_gui_none())
            except Exception as e:
                logging.error(f"Error in monitor_gpu: {e}")
            time.sleep(3)

    def update_gpu_gui(self, gpu_usage, gpu_memory_used, gpu_memory_total, gpu_memory_percent, gpu_temp):
        if self.stop_event.is_set():
            return
        self.gpu_usage_label.config(text=f"Current: {gpu_usage:.1f}%",
                                   foreground="red" if gpu_usage > 90 else "black")
        self.gpu_usage_history.append(gpu_usage)
        if len(self.gpu_usage_history) > self.max_history:
            self.gpu_usage_history.pop(0)

        gpu_usage_data = self.gpu_usage_history + [0] * (self.max_history - len(self.gpu_usage_history))
        self.gpu_usage_line.set_ydata(gpu_usage_data)
        self.gpu_usage_ax.relim()
        self.gpu_usage_ax.autoscale_view()
        self.gpu_usage_canvas.draw()

        self.gpu_memory_label.config(text=f"Used: {gpu_memory_used:.1f} MB | Total: {gpu_memory_total:.1f} MB | Percent: {gpu_memory_percent:.1f}%",
                                    foreground="red" if gpu_memory_percent > 90 else "black")
        self.gpu_memory_history.append(gpu_memory_percent)
        if len(self.gpu_memory_history) > self.max_history:
            self.gpu_memory_history.pop(0)

        gpu_memory_data = self.gpu_memory_history + [0] * (self.max_history - len(self.gpu_memory_history))
        self.gpu_memory_line.set_ydata(gpu_memory_data)
        self.gpu_memory_ax.relim()
        self.gpu_memory_ax.autoscale_view()
        self.gpu_memory_canvas.draw()

        self.gpu_temp_label.config(text=f"Current: {gpu_temp:.1f} | Min: {self.gpu_temp_min:.1f} | Max: {self.gpu_temp_max:.1f}",
                                  foreground="red" if gpu_temp > self.gpu_threshold else "black")
        self.gpu_temp_history.append(gpu_temp)
        if len(self.gpu_temp_history) > self.max_history:
            self.gpu_temp_history.pop(0)

        gpu_temp_data = self.gpu_temp_history + [0] * (self.max_history - len(self.gpu_temp_history))
        self.gpu_temp_line.set_ydata(gpu_temp_data)
        self.gpu_temp_ax.relim()
        self.gpu_temp_ax.autoscale_view()
        self.gpu_temp_canvas.draw()

        recommendation = "Recommendation: Reduce GPU-intensive tasks."
        if gpu_temp > self.gpu_threshold:
            alert_msg = f"GPU temperature exceeded {self.gpu_threshold}°C: {gpu_temp:.1f}°C"
            self.alert_log.append(f"{datetime.datetime.now()}: {alert_msg}")
            messagebox.showwarning("GPU Warning", f"{alert_msg}\n{recommendation}")

    def update_gpu_gui_none(self):
        if self.stop_event.is_set():
            return
        self.gpu_usage_label.config(text="Current: N/A")
        self.gpu_memory_label.config(text="Used: N/A MB | Total: N/A MB | Percent: N/A%")
        self.gpu_temp_label.config(text="Current: N/A | Min: N/A | Max: N/A")

    def monitor_disk(self):
        last_read_bytes = 0
        last_write_bytes = 0
        if getattr(sys, 'frozen', False):
            base_path = os.path.dirname(sys.executable)
            smartctl_path = os.path.join(base_path, 'smartctl.exe')
        else:
            smartctl_path = r"C:\Program Files\gsmartcontrol\smartctl.exe"
        while not self.stop_event.is_set():
            try:
                disk = psutil.disk_usage('/')
                io = psutil.disk_io_counters()
                disk_temp = "N/A"
                disk_health = "N/A"
                if platform.system() == "Windows":
                    try:
                        cmd = [smartctl_path, '-A', '-d', 'nvme', '/dev/sda']
                        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=5)
                        for line in result.stdout.splitlines():
                            if "Temperature:" in line:
                                temp_value = [word for word in line.split() if word.isdigit()]
                                disk_temp = temp_value[0] + "°C" if temp_value else "N/A"
                                break
                        cmd = [smartctl_path, '-H', '-d', 'nvme', '/dev/sda']
                        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=5)
                        disk_health = "OK" if "PASSED" in result.stdout else "Warning"
                    except subprocess.CalledProcessError:
                        disk_temp = "N/A"
                        disk_health = "N/A"
                    except FileNotFoundError:
                        disk_temp = "N/A"
                        disk_health = "N/A"
                elif platform.system() == "Linux" and SMART_AVAILABLE:
                    try:
                        disk_device = Device('/dev/sda')
                        disk_device.assessment
                        disk_temp = str(disk_device.temperature) + "°C" if disk_device.temperature else "N/A"
                        disk_health = disk_device.health if disk_device.health else "N/A"
                    except Exception:
                        disk_temp = "N/A"
                        disk_health = "N/A"
                if io:
                    read_speed = (io.read_bytes - last_read_bytes) / (1024 * 1024)
                    write_speed = (io.write_bytes - last_write_bytes) / (1024 * 1024)
                    last_read_bytes = io.read_bytes
                    last_write_bytes = io.write_bytes
                else:
                    read_speed = write_speed = 0
                self.root.after(0, lambda: self.update_disk_gui(disk, read_speed, write_speed, disk_temp, disk_health))
            except Exception as e:
                logging.error(f"Error in monitor_disk: {e}")
            time.sleep(3)

    def update_disk_gui(self, disk, read_speed, write_speed, disk_temp, disk_health):
        if self.stop_event.is_set():
            return
        free_percent = 100 - disk.percent
        self.disk_label.config(
            text=f"Disk Usage: {disk.percent:.1f}% ({disk.used/(1024**3):.2f}/{disk.total/(1024**3):.2f} GB, "
                 f"Free: {disk.free/(1024**3):.2f} GB)",
            foreground="red" if free_percent < self.disk_space_threshold else "black"
        )
        recommendation = "Recommendation: Free up disk space."
        if free_percent < self.disk_space_threshold:
            alert_msg = f"Free disk space is below {self.disk_space_threshold}%: {free_percent:.1f}%"
            self.alert_log.append(f"{datetime.datetime.now()}: {alert_msg}")
            messagebox.showwarning("Disk Space Warning", f"{alert_msg}\n{recommendation}")

        self.disk_smart_label.config(text=f"Temperature: {disk_temp} | Health: {disk_health}")

        self.disk_io_history_read.append(read_speed)
        self.disk_io_history_write.append(write_speed)
        if len(self.disk_io_history_read) > self.max_history:
            self.disk_io_history_read.pop(0)
            self.disk_io_history_write.pop(0)

        read_data = self.disk_io_history_read + [0] * (self.max_history - len(self.disk_io_history_read))
        write_data = self.disk_io_history_write + [0] * (self.max_history - len(self.disk_io_history_write))
        self.disk_io_read_line.set_ydata(read_data)
        self.disk_io_write_line.set_ydata(write_data)
        self.disk_io_ax.relim()
        self.disk_io_ax.autoscale_view()
        self.disk_io_canvas.draw()

    def monitor_network(self):
        last_bytes_sent = 0
        last_bytes_recv = 0
        while not self.stop_event.is_set():
            try:
                net_io = psutil.net_io_counters()
                download_speed = (net_io.bytes_recv - last_bytes_recv) * 8 / (1024 * 1024)
                upload_speed = (net_io.bytes_sent - last_bytes_sent) * 8 / (1024 * 1024)
                last_bytes_recv = net_io.bytes_recv
                last_bytes_sent = net_io.bytes_sent
                self.root.after(0, lambda: self.update_network_gui(download_speed, upload_speed))
            except Exception as e:
                logging.error(f"Error in monitor_network: {e}")
            time.sleep(3)

    def update_network_gui(self, download_speed, upload_speed):
        if self.stop_event.is_set():
            return
        self.net_label.config(
            text=f"Network: Download {download_speed:.1f} Mbps | Upload {upload_speed:.1f} Mbps",
            foreground="red" if (download_speed > self.net_traffic_threshold or upload_speed > self.net_traffic_threshold) else "black"
        )
        recommendation = "Recommendation: Check network-intensive processes."
        if (download_speed > self.net_traffic_threshold or upload_speed > self.net_traffic_threshold):
            alert_msg = f"Unusual network activity: Download {download_speed:.1f} Mbps, Upload {upload_speed:.1f} Mbps"
            self.alert_log.append(f"{datetime.datetime.now()}: {alert_msg}")
            messagebox.showwarning("Network Warning", f"{alert_msg}\n{recommendation}")

        self.net_download_history.append(download_speed)
        self.net_upload_history.append(upload_speed)
        if len(self.net_download_history) > self.max_history:
            self.net_download_history.pop(0)
            self.net_upload_history.pop(0)

        download_data = self.net_download_history + [0] * (self.max_history - len(self.net_download_history))
        upload_data = self.net_upload_history + [0] * (self.max_history - len(self.net_upload_history))
        self.net_download_line.set_ydata(download_data)
        self.net_upload_line.set_ydata(upload_data)
        self.net_ax.relim()
        self.net_ax.autoscale_view()
        self.net_canvas.draw()

        self.update_net_process_list()

    def monitor_uptime(self):
        while not self.stop_event.is_set():
            try:
                uptime_seconds = int(time.time() - psutil.boot_time())
                days, remainder = divmod(uptime_seconds, 86400)
                hours, remainder = divmod(remainder, 3600)
                minutes, seconds = divmod(remainder, 60)
                self.root.after(0, lambda: self.update_uptime_gui(uptime_seconds, days, hours, minutes))
            except Exception as e:
                logging.error(f"Error in monitor_uptime: {e}")
            time.sleep(60)

    def update_uptime_gui(self, uptime_seconds, days, hours, minutes):
        if self.stop_event.is_set():
            return
        self.uptime_label.config(text=f"Uptime: {days}d {hours}h {minutes}m")
        recommendation = "Recommendation: Consider rebooting the system."
        if uptime_seconds > self.uptime_threshold:
            alert_msg = f"System running for over 7 days: {days}d {hours}h {minutes}m"
            self.alert_log.append(f"{datetime.datetime.now()}: {alert_msg}")
            messagebox.showwarning("Uptime Warning", f"{alert_msg}\n{recommendation}")

        self.update_system_info()

    def clear_all_tags(self):
        try:
            for item in self.process_tree.get_children():
                current_tags = self.process_tree.item(item, 'tags')
                new_tags = tuple(t for t in current_tags if t not in ('new', 'updated'))
                self.process_tree.item(item, tags=new_tags)
            for item in self.net_process_tree.get_children():
                current_tags = self.net_process_tree.item(item, 'tags')
                new_tags = tuple(t for t in current_tags if t not in ('new', 'updated'))
                self.net_process_tree.item(item, tags=new_tags)
        except tk.TclError:
            pass

    def schedule_clear_tags(self):
        if self.stop_event.is_set():
            return
        self.clear_all_tags()
        self.clear_tags_after_id = self.root.after(2000, self.schedule_clear_tags)
        self.after_ids.append(self.clear_tags_after_id)

    def update_process_list(self):
        if self.stop_event.is_set():
            return
        selected = self.process_tree.selection()
        selected_pid = None
        if selected:
            selected_pid = self.process_tree.item(selected[0])['values'][0]

        new_process_data = {}
        try:
            process_list = list(psutil.process_iter(['pid', 'name', 'memory_percent', 'memory_info', 'cpu_percent']))
            if len(process_list) > 50 and not self.process_limit_warning_shown:
                self.process_limit_warning_shown = True
                self.root.after(0, lambda: messagebox.showwarning("Warning", "Too many processes detected. Displaying top 50 processes to optimize performance."))

            for proc in process_list[:50]:
                try:
                    pid = proc.info['pid']
                    new_process_data[pid] = {
                        'name': proc.info['name'],
                        'memory_mb': proc.info['memory_info'].rss / (1024 * 1024),
                        'memory_percent': proc.info['memory_percent'],
                        'cpu_percent': proc.info['cpu_percent']
                    }
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            logging.error(f"Error in update_process_list: {e}")
            return

        current_pids = set(self.process_data.keys())
        new_pids = set(new_process_data.keys())

        for pid in current_pids - new_pids:
            for item in self.process_tree.get_children():
                if int(self.process_tree.item(item)['values'][0]) == pid:
                    self.process_tree.delete(item)
                    break

        sorted_processes = sorted(new_process_data.items(),
                                 key=lambda x: self.get_sort_key(x[1], x[0]),
                                 reverse=self.sort_reverse)

        self.process_tree.delete(*self.process_tree.get_children())
        for pid, data in sorted_processes:
            values = (pid,
                      data['name'],
                      f"{data['memory_mb']:.2f}",
                      f"{data['memory_percent']:.2f}",
                      f"{data['cpu_percent']:.2f}")
            item = self.process_tree.insert("", "end", values=values)
            if data['cpu_percent'] > 90 or data['memory_percent'] > 90:
                self.process_tree.item(item, tags=('high_load',))

            if pid not in self.process_data:
                self.process_tree.item(item, tags=('new',))
            elif self.process_data.get(pid) != data:
                self.process_tree.item(item, tags=('updated',))

        self.process_tree.tag_configure('new', background='#90EE90')
        self.process_tree.tag_configure('updated', background='#FFFFE0')
        self.process_tree.tag_configure('high_load', background='#FF6347')

        if selected_pid:
            for item in self.process_tree.get_children():
                if int(self.process_tree.item(item)['values'][0]) == selected_pid:
                    self.process_tree.selection_set(item)
                    break

        self.process_data = new_process_data

    def update_net_process_list(self):
        if self.stop_event.is_set():
            return
        selected = self.net_process_tree.selection()
        selected_pid = None
        if selected:
            selected_pid = self.net_process_tree.item(selected[0])['values'][0]

        new_net_process_data = {}
        try:
            for proc in list(psutil.process_iter(['pid', 'name']))[:50]:
                try:
                    pid = proc.info['pid']
                    net_connections = proc.net_connections()
                    if net_connections:
                        download_mb = sum(conn.bytes_recv for conn in net_connections if hasattr(conn, 'bytes_recv')) / (1024 * 1024)
                        upload_mb = sum(conn.bytes_sent for conn in net_connections if hasattr(conn, 'bytes_sent')) / (1024 * 1024)
                        new_net_process_data[pid] = {
                            'name': proc.info['name'],
                            'download_mb': download_mb,
                            'upload_mb': upload_mb
                        }
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            logging.error(f"Error in update_net_process_list: {e}")
            return

        current_pids = set(self.net_process_data.keys())
        new_pids = set(new_net_process_data.keys())

        for pid in current_pids - new_pids:
            for item in self.net_process_tree.get_children():
                if int(self.net_process_tree.item(item)['values'][0]) == pid:
                    self.net_process_tree.delete(item)
                    break

        sorted_net_processes = sorted(new_net_process_data.items(),
                                     key=lambda x: self.get_net_sort_key(x[1], x[0]),
                                     reverse=self.net_sort_reverse)

        self.net_process_tree.delete(*self.net_process_tree.get_children())
        for pid, data in sorted_net_processes:
            values = (pid,
                      data['name'],
                      f"{data['download_mb']:.2f}",
                      f"{data['upload_mb']:.2f}")
            item = self.net_process_tree.insert("", "end", values=values)

            if pid not in self.net_process_data:
                self.net_process_tree.item(item, tags=('new',))
            elif self.net_process_data.get(pid) != data:
                self.net_process_tree.item(item, tags=('updated',))

        self.net_process_tree.tag_configure('new', background='#90EE90')
        self.net_process_tree.tag_configure('updated', background='#FFFFE0')

        if selected_pid:
            for item in self.net_process_tree.get_children():
                if int(self.net_process_tree.item(item)['values'][0]) == selected_pid:
                    self.net_process_tree.selection_set(item)
                    break

        self.net_process_data = new_net_process_data

    def get_sort_key(self, data, pid):
        if self.sort_column == "PID":
            return pid
        elif self.sort_column == "Name":
            return data['name'].lower()
        elif self.sort_column == "Memory_MB":
            return data['memory_mb']
        elif self.sort_column == "Memory_Percent":
            return data['memory_percent']
        elif self.sort_column == "CPU_Percent":
            return data['cpu_percent']
        return 0

    def get_net_sort_key(self, data, pid):
        if self.net_sort_column == "PID":
            return pid
        elif self.net_sort_column == "Name":
            return data['name'].lower()
        elif self.net_sort_column == "Download_MB":
            return data['download_mb']
        elif self.net_sort_column == "Upload_MB":
            return data['upload_mb']
        return 0

    def kill_process(self):
        selected = self.process_tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a process to terminate")
            return

        pid = int(self.process_tree.item(selected[0])['values'][0])

        if messagebox.askyesno("Confirm", f"Are you sure you want to terminate process PID {pid}?"):
            try:
                process = psutil.Process(pid)
                process.terminate()
                time.sleep(0.5)
                if process.is_running():
                    process.kill()
                messagebox.showinfo("Success", f"Process {pid} terminated")
                self.root.after(100, self.update_process_list)
            except psutil.NoSuchProcess:
                messagebox.showerror("Error", "Process no longer exists")
                self.root.after(100, self.update_process_list)
            except psutil.AccessDenied:
                messagebox.showerror("Error", "Access denied to terminate this process")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to terminate process: {str(e)}")
                self.root.after(100, self.update_process_list)

    def export_data(self, time_range_minutes=None):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"system_report_{timestamp}.txt"

        with open(filename, 'w', encoding='utf-8') as f:
            f.write("System Monitoring Report\n")
            f.write(f"Date: {timestamp}\n")
            if time_range_minutes:
                f.write(f"Time Range: Last {time_range_minutes} minutes\n")
            f.write("\n")

            info = self.get_system_info()
            for key, value in info.items():
                f.write(f"{key}: {value}\n")

            f.write(f"\nCPU Usage: {psutil.cpu_percent()}%\n")
            if time_range_minutes:
                history_points = min(len(self.cpu_usage_history[0]), int(time_range_minutes * 60 / 3))
                avg_cpu = [sum(core[i] for core in self.cpu_usage_history) / len(self.cpu_usage_history)
                           for i in range(-history_points, 0)] if self.cpu_usage_history else []
                f.write(f"Average CPU Usage (last {time_range_minutes} min): {sum(avg_cpu)/len(avg_cpu):.1f}%"
                        if avg_cpu else "N/A\n")

            ram = psutil.virtual_memory()
            f.write(f"RAM Usage: {ram.percent}% ({ram.used/(1024**3):.2f}/{ram.total/(1024**3):.2f} GB, "
                    f"Free: {ram.free/(1024**3):.2f} GB)\n")
            if time_range_minutes:
                history_points = min(len(self.ram_usage_history), int(time_range_minutes * 60 / 3))
                avg_ram = self.ram_usage_history[-history_points:] if self.ram_usage_history else []
                f.write(f"Average RAM Usage (last {time_range_minutes} min): {sum(avg_ram)/len(avg_ram):.1f}%"
                        if avg_ram else "N/A\n")

            f.write(f"Disk Usage: {self.disk_label['text']}\n")
            f.write(f"Disk Health: {self.disk_smart_label['text']}\n")
            if time_range_minutes:
                history_points = min(len(self.disk_io_history_read), int(time_range_minutes * 60 / 3))
                avg_read = self.disk_io_history_read[-history_points:] if self.disk_io_history_read else []
                avg_write = self.disk_io_history_write[-history_points:] if self.disk_io_history_write else []
                f.write(f"Average Disk Read (last {time_range_minutes} min): {sum(avg_read)/len(avg_read):.2f} MB/s"
                        if avg_read else "N/A\n")
                f.write(f"Average Disk Write (last {time_range_minutes} min): {sum(avg_write)/len(avg_write):.2f} MB/s"
                        if avg_write else "N/A\n")

            if GPU_AVAILABLE:
                f.write(f"GPU Usage: {self.gpu_usage_label['text']}\n")
                f.write(f"GPU Memory: {self.gpu_memory_label['text']}\n")
                f.write(f"GPU Temp: {self.gpu_temp_label['text']}\n")
                if time_range_minutes:
                    history_points = min(len(self.gpu_usage_history), int(time_range_minutes * 60 / 3))
                    avg_gpu = self.gpu_usage_history[-history_points:] if self.gpu_usage_history else []
                    f.write(f"Average GPU Usage (last {time_range_minutes} min): {sum(avg_gpu)/len(avg_gpu):.1f}%"
                            if avg_gpu else "N/A\n")

            f.write(f"Network: {self.net_label['text']}\n")
            if time_range_minutes:
                history_points = min(len(self.net_download_history), int(time_range_minutes * 60 / 3))
                avg_download = self.net_download_history[-history_points:] if self.net_download_history else []
                avg_upload = self.net_upload_history[-history_points:] if self.net_upload_history else []
                f.write(f"Average Download (last {time_range_minutes} min): {sum(avg_download)/len(avg_download):.2f} Mbps"
                        if avg_download else "N/A\n")
                f.write(f"Average Upload (last {time_range_minutes} min): {sum(avg_upload)/len(avg_upload):.2f} Mbps"
                        if avg_upload else "N/A\n")

            f.write("\nRunning Processes:\n")
            f.write("-" * 70 + "\n")
            f.write(f"{'PID':<8} {'Memory (MB)':<12} {'Memory (%)':<12} {'CPU (%)':<12} {'Process Name':<30}\n")
            processes = sorted(self.process_data.items(),
                              key=lambda x: self.get_sort_key(x[1], x[0]),
                              reverse=self.sort_reverse)
            for pid, data in processes[:10]:
                f.write(f"{pid:<8} {data['memory_mb']:<12.2f} {data['memory_percent']:<12.2f} "
                       f"{data['cpu_percent']:<12.2f} {data['name']:<30}\n")

            f.write("\nNetwork-Using Processes:\n")
            f.write("-" * 70 + "\n")
            f.write(f"{'PID':<8} {'Download (MB)':<15} {'Upload (MB)':<15} {'Process Name':<30}\n")
            net_processes = sorted(self.net_process_data.items(),
                                  key=lambda x: self.get_net_sort_key(x[1], x[0]),
                                  reverse=self.net_sort_reverse)
            for pid, data in net_processes[:10]:
                f.write(f"{pid:<8} {data['download_mb']:<15.2f} {data['upload_mb']:<15.2f} {data['name']:<30}\n")

            f.write("\nReboot History:\n")
            f.write("-" * 70 + "\n")
            for reboot_time in self.reboot_history:
                f.write(f"{reboot_time}\n")

            f.write("\nAlert Log:\n")
            f.write("-" * 70 + "\n")
            for alert in self.alert_log[-10:]:
                f.write(f"{alert}\n")

        return filename

    def manual_export_data(self):
        time_range = simpledialog.askinteger("Export", "Enter time range (minutes, 0 for current data):",
                                            minvalue=0, maxvalue=60)
        filename = self.export_data(time_range if time_range else None)
        messagebox.showinfo("Success", f"Data exported to {filename}")

    def auto_export_data(self):
        if self.stop_event.is_set():
            return
        filename = self.export_data(time_range_minutes=5)
        self.after_ids.append(self.root.after(self.auto_export_interval * 1000, self.auto_export_data))

    def start_monitoring(self):
        Thread(target=self.monitor_cpu, daemon=True).start()
        Thread(target=self.monitor_ram, daemon=True).start()
        if GPU_AVAILABLE:
            Thread(target=self.monitor_gpu, daemon=True).start()
        Thread(target=self.monitor_disk, daemon=True).start()
        Thread(target=self.monitor_network, daemon=True).start()
        Thread(target=self.monitor_uptime, daemon=True).start()
        self.schedule_clear_tags()
        self.after_ids.append(self.root.after(self.auto_export_interval * 1000, self.auto_export_data))

    def on_closing(self):
        logging.info("Initiating application shutdown")
        self.stop_event.set()  # Сигнал для зупинки всіх потоків

        # Скасування всіх after завдань
        if self.clear_tags_after_id:
            try:
                self.root.after_cancel(self.clear_tags_after_id)
                logging.info(f"Cancelled clear_tags_after_id: {self.clear_tags_after_id}")
            except tk.TclError as e:
                logging.error(f"Error cancelling clear_tags_after_id: {e}")
        for after_id in self.after_ids:
            try:
                self.root.after_cancel(after_id)
                logging.info(f"Cancelled after_id: {after_id}")
            except tk.TclError as e:
                logging.error(f"Error cancelling after_id {after_id}: {e}")
        self.after_ids.clear()

        # Закриття всіх matplotlib canvas
        try:
            self.cpu_canvas.get_tk_widget().destroy()
            self.ram_canvas.get_tk_widget().destroy()
            self.disk_io_canvas.get_tk_widget().destroy()
            self.net_canvas.get_tk_widget().destroy()
            if GPU_AVAILABLE:
                self.gpu_usage_canvas.get_tk_widget().destroy()
                self.gpu_memory_canvas.get_tk_widget().destroy()
                self.gpu_temp_canvas.get_tk_widget().destroy()
            plt.close('all')  # Закрити всі matplotlib фігури
            logging.info("Closed all matplotlib canvases")
        except Exception as e:
            logging.error(f"Error closing matplotlib canvases: {e}")

        # Відновлення stdout
        try:
            self.devnull_file.close()
            sys.stdout = self.original_stdout
            logging.info("Restored sys.stdout")
        except Exception as e:
            logging.error(f"Error restoring sys.stdout: {e}")

        # Завершення GUI
        try:
            self.root.destroy()
            logging.info("Destroyed Tkinter root")
        except Exception as e:
            logging.error(f"Error destroying Tkinter root: {e}")

        # Примусове завершення процесу через 2 секунди, якщо не завершилося
        self.root.after(2000, lambda: os._exit(0))

    def run(self):
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.mainloop()

if __name__ == "__main__":
    try:
        monitor = SystemMonitor()
        monitor.run()
    except Exception as e:
        logging.critical(f"Fatal error in main: {e}")
        os._exit(1)